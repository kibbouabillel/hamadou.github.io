<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&amp;subset=devanagari,latin-ext" rel="stylesheet">
        
        <!-- title of site -->
        <title>CURRICULUM VITAE</title>

        <!-- For favicon png -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

		<!--flat icon css-->
		<link rel="stylesheet" href="assets/css/flaticon.css">

		<!--animate.css-->
        <link rel="stylesheet" href="assets/css/animate.css">

        <!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
		
        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css" >	
        
        <!--style.css-->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="assets/css/responsive.css">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		
        <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
	
	<body>
		<!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
		
		<!-- top-area Start -->
		<header class="top-area">
			<div class="header-area">
				<!-- Start Navigation -->
			    <nav class="navbar navbar-default bootsnav navbar-fixed dark no-background">

			        <div class="container">

			            <!-- Start Header Navigation -->
			            <div class="navbar-header">
			                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
			                    <i class="fa fa-bars"></i>
			                </button>
			                <a class="navbar-brand" href="index.php">CURRICULUM VITAE</a>
			            </div><!--/.navbar-header-->
			            <!-- End Header Navigation -->

			            <!-- Collect the nav links, forms, and other content for toggling -->
			            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
			                <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
			                <li class=" smooth-menu active"></li>
			                    <li class=" smooth-menu"><a href="#education">ÉDUCATION</a></li>
			                    <li class="smooth-menu"><a href="#skills">LANGUE ET LOGICIEL MAITRISÉ</a></li>
			                    <li class="smooth-menu"><a href="#experience">Expérience</a></li>
			                    <li class="smooth-menu"><a href="#profiles">CENTRES D’INTERETS</a></li>
			                    <li class="smooth-menu"><a href="#portfolio">portfolio</a></li>
			                    <li class="smooth-menu"><a href="#contact">contact</a></li>
			                </ul><!--/.nav -->
			            </div><!-- /.navbar-collapse -->
			        </div><!--/.container-->
			    </nav><!--/nav-->
			    <!-- End Navigation -->
			</div><!--/.header-area-->

		    <div class="clearfix"></div>

		</header><!-- /.top-area-->
		<!-- top-area End -->
	
		<!--welcome-hero start -->
		<section id="welcome-hero" class="welcome-hero">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<div class="header-text">
							<h2>hi <span>,</span> i am <br> hamadou <br> souhila <span>.</span>   </h2>
							<p>Biochimiste & Immunologue</p>
							<a href="assets/download/cv.pdf" download>Télécharger Mon CV</a>
						</div><!--/.header-text-->
					</div><!--/.col-->
				</div><!-- /.row-->
			</div><!-- /.container-->

		</section><!--/.welcome-hero-->
		<!--welcome-hero end -->

		<!--about start -->
		<section id="about" class="about">
			<div class="section-heading text-center">
				<h2>À PROPOS DE MOI</h2>
			</div>
			<div class="container">
				<div class="about-content">
					<div class="row">
						<div class="col-sm-6">
							<div class="single-about-txt">
								<h3>

Hamadou Souhila 24 ANS, Biologiste spécialisée en biochimie immunologie, ouverte d'esprit, curieuse, motivée  et ayant  le sens de l'écoute. Dotée d'une aisance  dans les relations  publiques (facilité à développer et entretenir des liens de longue durée avec les différents interlocuteurs)
Avec une connaissance linguistique du Français, Arabe, Anglais et kabyle...</h3>
								<p>
Adresse cité AADL 1 Bt°27 N°18, Bab Ezzouar, Alger / "Code Postal: 16042"<br/>Permis de conduire catégorie B, véhiculée	</p>
								<div class="row">
									<div class="col-sm-4">
										<div class="single-about-add-info">
											<h3>Téléphone</h3>
											<p>+213 541 461 871</p>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="single-about-add-info">
											<h3>Email</h3>
											<p>hamadousouhila87@gmail.com</p>
											
										</div>
									</div>
								
								</div>
							</div>
						</div>
						<div class="col-sm-offset-1 col-sm-5">
							<div class="single-about-img">
								<img src="assets/images/about/profile_image.jpg" alt="profile_image">
								<div class="about-list-icon">
									<ul>
										<li>
											<a href="#">
												<i  class="fa fa-facebook" aria-hidden="true"></i>
											</a>
										</li><!-- / li -->
									
										<li>
											<a href="#">
												<i  class="fa fa-twitter" aria-hidden="true"></i>
											</a>
											
										</li><!-- / li -->
										<li>
											<a href="#">
												<i  class="fa fa-linkedin" aria-hidden="true"></i>
											</a>
										</li><!-- / li -->
										<li>
											<a href="#">
												<i  class="fa fa-instagram" aria-hidden="true"></i>
											</a>
										</li><!-- / li -->
										
										
									</ul><!-- / ul -->
								</div><!-- /.about-list-icon -->

							</div>

						</div>
					</div>
				</div>
			</div>
		</section><!--/.about-->
		<!--about end -->
		
		<!--education start -->
		<section id="education" class="education">
			<div class="section-heading text-center">
				<h2>ÉDUCATION</h2>
			</div>
			<div class="container">
				<div class="education-horizontal-timeline">
					<div class="row">
						<div class="col-sm-4">
							<div class="single-horizontal-timeline">
								<div class="experience-time">
									<h2>2019</h2>
									<h3>master 2 <span>en </span>biochimie immunologie</h3>
								</div><!--/.experience-time-->
								<div class="timeline-horizontal-border">
									<i class="fa fa-circle" aria-hidden="true"></i>
									<span class="single-timeline-horizontal"></span>
								</div>
								<div class="timeline">
									<div class="timeline-content">
										<h4 class="title">
											Université  des Sciences et de la Technologie HOUARI BOUMEDIENE 
										</h4>
									<!--	<h5>north carolina, USA</h5>
										<p class="description">
											Duis aute irure dolor in reprehenderit in vol patate velit esse cillum dolore eu fugiat nulla pari. Excepteur sint occana inna tecat cupidatat non proident. 
										</p>  -->
									</div> <!--/.timeline-content-->
								</div><!--/.timeline-->
							</div>
						</div>
						<div class="col-sm-4">
							<div class="single-horizontal-timeline">
								<div class="experience-time">
									<h2>2017</h2>
									<h3>Licence <span>en </span> Biochimie</h3>
								</div><!--/.experience-time-->
								<div class="timeline-horizontal-border">
									<i class="fa fa-circle" aria-hidden="true"></i>
									<span class="single-timeline-horizontal"></span>
								</div>
								<div class="timeline">
									<div class="timeline-content">
										<h4 class="title">
											Université  des Sciences et de la Technologie HOUARI BOUMEDIENE 
										</h4>
									<!--	<h5>north carolina, USA</h5>
										<p class="description">
											Duis aute irure dolor in reprehenderit in vol patate velit esse cillum dolore eu fugiat nulla pari. Excepteur sint occana inna tecat cupidatat non proident. 
										</p>  -->
									</div><!--/.timeline-content-->
								</div><!--/.timeline-->
							</div>
						</div>
						<div class="col-sm-4">
							<div class="single-horizontal-timeline">
								<div class="experience-time">
									<h2>2014</h2>
									<h3>Baccalauréat sciences experimentales</h3>
								</div><!--/.experience-time-->
								<div class="timeline-horizontal-border">
									<i class="fa fa-circle" aria-hidden="true"></i>
									<span class="single-timeline-horizontal spacial-horizontal-line
									"></span>
								</div>
								<div class="timeline">
									<div class="timeline-content">
										<h4 class="title">
											Lycée Mohamed El Bjaoui  
										</h4>
									<!--	<h5>north carolina, USA</h5>
										<p class="description">
											Duis aute irure dolor in reprehenderit in vol patate velit esse cillum dolore eu fugiat nulla pari. Excepteur sint occana inna tecat cupidatat non proident. 
										</p>  -->
									</div><!--/.timeline-content-->
								</div><!--/.timeline-->
							</div>
						</div>
					</div>
				</div>
			</div>

		</section><!--/.education-->
		<!--education end -->

		<!--skills start -->
		<section id="skills" class="skills">
				<div class="skill-content">
					<div class="section-heading text-center">
						<h2>langues et logiciels maitrisés</h2>
					</div>
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<div class="single-skill-content">
									<div class="barWrapper">
										<span class="progressText">Microsoft Word</span>
										<div class="single-progress-txt">
											<div class="progress ">
												<div class="progress-bar" role="progressbar" aria-valuenow="92" aria-valuemin="10" aria-valuemax="100" style="">
													  
												</div>
											</div>
											<h3>92%</h3>	
										</div>
									</div><!-- /.barWrapper -->
									<div class="barWrapper">
										<span class="progressText">Microsoft Excel</span>
										<div class="single-progress-txt">
											<div class="progress ">
											   <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="10" aria-valuemax="100" style="">
												    
											   </div>
											</div>
											<h3>90%</h3>	
										</div>
									</div><!-- /.barWrapper -->
									<div class="barWrapper">
										<span class="progressText">Microsoft powerpoint</span>
										<div class="single-progress-txt">
											<div class="progress ">
											   <div class="progress-bar" role="progressbar" aria-valuenow="97" aria-valuemin="10" aria-valuemax="100" style="">
												   
											   </div>
											</div>
											<h3>97%</h3>	
										</div>
									</div><!-- /.barWrapper -->
									<div class="barWrapper">
										<span class="progressText">adobe photoshop</span>
										<div class="single-progress-txt">
											<div class="progress ">
											   <div class="progress-bar" role="progressbar" aria-valuenow="40" aria-valuemin="10" aria-valuemax="100" style="">
												    
											   </div>
											</div>
											<h3>40%</h3>	
										</div>
									</div><!-- /.barWrapper -->
								</div>
							</div>
							<div class="col-md-6">
								<div class="single-skill-content">
									<div class="barWrapper">
										<span class="progressText">Arabe</span>
										<div class="single-progress-txt">
											<div class="progress ">
												<div class="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="10" aria-valuemax="100" style="">
													
												</div>
											</div>
											<h3>95%</h3>	
										</div>
									</div><!-- /.barWrapper -->
									<div class="barWrapper">
										<span class="progressText">français</span>
										<div class="single-progress-txt">
											<div class="progress ">
											   <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="10" aria-valuemax="100" style="">
												    
											   </div>
											</div>
											<h3>90%</h3>	
										</div>
									</div><!-- /.barWrapper -->
									<div class="barWrapper">
										<span class="progressText">anglais</span>
										<div class="single-progress-txt">
											<div class="progress ">
											   <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="10" aria-valuemax="100" style="">
												   
											   </div>
											</div>
											<h3>70%</h3>	
										</div>
									</div><!-- /.barWrapper -->
									<div class="barWrapper">
										<span class="progressText">kabyle</span>
										<div class="single-progress-txt">
											<div class="progress ">
											   <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="10" aria-valuemax="100" style="">
												    
											   </div>
											</div>
											<h3>80%</h3>	
										</div>
									</div><!-- /.barWrapper -->
								</div>
							</div>
						</div><!-- /.row -->
					</div>	<!-- /.container -->		
				</div><!-- /.skill-content-->

		</section><!--/.skills-->
		<!--skills end -->

		<!--experience start -->
		<section id="experience" class="experience">
			<div class="section-heading text-center">
				<h2>Expériences</h2>
			</div>
			<div class="container">
				<div class="experience-content">
						<div class="main-timeline">
							<ul>
								<li>
									<div class="single-timeline-box fix">
										<div class="row">
											<div class="col-md-5">
												<div class="experience-time text-right">
													<h2>Janvier – Juin 2019</h2>
													<h3>Alger-Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
											<div class="col-md-offset-1 col-md-5">
												<div class="timeline">
													<div class="timeline-content">
														<h4 class="title">
															<span><i class="fa fa-circle" aria-hidden="true"></i></span>
															Community Manager de l’agence Authentic Algeria
														</h4>
														
													</div><!--/.timeline-content-->
												</div><!--/.timeline-->
											</div><!--/.col-->
										</div>
									</div><!--/.single-timeline-box-->
								</li>

								<li>
									<div class="single-timeline-box fix">
										<div class="row">
											<div class="col-md-offset-1 col-md-5 experience-time-responsive">
												<div class="experience-time">
													<h2>
														<span><i class="fa fa-circle" aria-hidden="true"></i></span>
													Mai 2019
													</h2>
													<h3>Alger-Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
											<div class="col-md-5">
												<div class="timeline">
													<div class="timeline-content text-right">
														<h4 class="title">
															Stage du PFE au niveau du laboratoire d’Anatomie Pathologie du CHU d’Alger Mustapha Pacha
														</h4>
													
													</div><!--/.timeline-content-->
												</div><!--/.timeline-->
											</div><!--/.col-->
											<div class="col-md-offset-1 col-md-5 experience-time-main">
												<div class="experience-time">
													<h2>
														<span><i class="fa fa-circle" aria-hidden="true"></i></span>
														Mai 2019
													</h2>
													<h3>Alger-Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
										</div>
									</div><!--/.single-timeline-box-->
								</li>

								<li>
									<div class="single-timeline-box fix">
										<div class="row">
											<div class="col-md-5">
												<div class="experience-time text-right">
													<h2>Septembre 2018</h2>
													<h3>Alger-Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
											<div class="col-md-offset-1 col-md-5">
												<div class="timeline">
													<div class="timeline-content">
														<h4 class="title">
															<span><i class="fa fa-circle" aria-hidden="true"></i></span>
															Stage pratique au Centre Hospitalo-Universitaire D’HUSSEIN-DEY, laboratoire de physiologie clinique et exploration fonctionnelle
métabolique et nutrition
														</h4>
														
													</div><!--/.timeline-content-->
												</div><!--/.timeline-->
											</div><!--/.col-->
										</div>
									</div><!--/.single-timeline-box-->
								</li>

								<li>
									<div class="single-timeline-box fix">
										<div class="row">
											<div class="col-md-offset-1 col-md-5 experience-time-responsive">
												<div class="experience-time">
													<h2>
														<span><i class="fa fa-circle" aria-hidden="true"></i></span>
														Juin- septembre 2017
													</h2>
													<h3>Alger-Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
											<div class="col-md-5">
												<div class="timeline">
													<div class="timeline-content text-right">
														<h4 class="title">
															Commerciale au niveau de l’agence de voyage Essafaria Travel
														</h4>
														
													</div><!--/.timeline-content-->
												</div><!--/.timeline-->
											</div><!--/.col-->
											<div class="col-md-offset-1 col-md-5 experience-time-main">
												<div class="experience-time">
													<h2>
														<span><i class="fa fa-circle" aria-hidden="true"></i></span>
														Juin- septembre 2017
													</h2>
													<h3>Alger Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
										</div>
									</div><!--/.single-timeline-box-->
								</li>

								<li>
									<div class="single-timeline-box fix">
										<div class="row">
											<div class="col-md-5">
												<div class="experience-time text-right">
													<h2>Juillet 2016</h2>
													<h3>Alger Algérie</h3>
												</div><!--/.experience-time-->
											</div><!--/.col-->
											<div class="col-md-offset-1 col-md-5">
												<div class="timeline">
													<div class="timeline-content">
														<h4 class="title">
															<span><i class="fa fa-circle" aria-hidden="true"></i></span>
														Stage pratique au Centre Hospitalo-universitaire- Mustapha, Service d’Immunologie
														</h4>
													
													</div><!--/.timeline-content-->
												</div><!--/.timeline-->
											</div><!--/.col-->
										</div>
									</div><!--/.single-timeline-box-->
								</li>

							</ul>
						</div><!--.main-timeline-->
					</div><!--.experience-content-->
			</div>

		</section><!--/.experience-->
		<!--experience end -->

		<!--profiles start -->
		<section id="profiles" class="profiles">
			<div class="profiles-details">
				<div class="section-heading text-center">
					<h2>CENTRES D’INTERETS</h2>
				</div>
				<div class="container">
					<div class="profiles-content">
						<div class="row">
							<div class="col-sm-3">
								<div class="single-profile">
									<div class="profile-txt">
										<a href=""><i class="flaticon-themeforest"></i></a>
										<div class="profile-icon-name">Sports / cuisine</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-themeforest"></i></a>
											<div class="profile-icon-name">Sports / cuisine</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="single-profile">
									<div class="profile-txt">
										<a href=""><i class="flaticon-dribbble"></i></a>
										<div class="profile-icon-name">Association : membre de l’AIESEC</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-dribbble"></i></a>
											<div class="profile-icon-name">Association : membre de l’AIESEC</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="single-profile">
									<div class="profile-txt">
										<a href=""><i class="flaticon-dribbble"></i></a>
										<div class="profile-icon-name">Relaxation / Lecture </div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-behance-logo"></i></a>
											<div class="profile-icon-name">Relaxation / Lecture</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="single-profile profile-no-border">
									<div class="profile-txt">
										<a href=""><i class="flaticon-squarespace-logo"></i></a>
										<div class="profile-icon-name">Culture générale / voyages</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-squarespace-logo"></i></a>
											<div class="profile-icon-name">Culture générale / voyages</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="profile-border"></div>
						<div class="row">
							<div class="col-sm-3">
								<div class="single-profile">
									<div class="profile-txt">
										<a href=""><i class="flaticon-flickr-website-logo-silhouette"></i></a>
										<div class="profile-icon-name">Dynamique et ponctuelle</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-flickr-website-logo-silhouette"></i></a>
											<div class="profile-icon-name">Dynamique et ponctuelle</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="single-profile">
									<div class="profile-txt">
										<a href=""><i class="flaticon-smug"></i></a>
										<div class="profile-icon-name">Sens de communication</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-smug"></i></a>
											<div class="profile-icon-name">Sens de communication</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="single-profile">
									<div class="profile-txt">
										<a href=""><i class="flaticon-smug"></i></a>
										<div class="profile-icon-name">Capacité de travailler en groupe</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-smug"></i></a>
											<div class="profile-icon-name">Capacité de travailler en groupe</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="single-profile profile-no-border">
									<div class="profile-txt">
										<a href=""><i class="flaticon-flickr-website-logo-silhouette"></i></a>
										<div class="profile-icon-name">Flexibilité</div>
									</div>
									<div class="single-profile-overlay">
										<div class="profile-txt">
											<a href=""><i class="flaticon-flickr-website-logo-silhouette"></i></a>
											<div class="profile-icon-name">Flexibilité</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</section><!--/.profiles-->
		<!--profiles end -->

		<!--portfolio start -->
		<section id="portfolio" class="portfolio">
			<div class="portfolio-details">
				<div class="section-heading text-center">
					<h2>portfolio</h2>
				</div>
				<div class="container">
					<div class="portfolio-content">
						<div class="isotope">
							<div class="row">

								<div class="col-sm-4">
									<div class="item">
										<img src="assets/images/portfolio/p1.jpg" alt="portfolio image" style="height:250px; width:100%;"/>
										<div class="isotope-overlay">
										
										</div><!-- /.isotope-overlay -->
									</div><!-- /.item -->
									<div class="item">
										<img src="assets/images/portfolio/p2.jpg" alt="portfolio image" style="height:250px; width:100%;"/>
										<div class="isotope-overlay">
										
										</div><!-- /.isotope-overlay -->
									</div><!-- /.item -->
								</div><!-- /.col -->

								<div class="col-sm-4">
									<div class="item">
										<img src="assets/images/portfolio/p3.jpg" alt="portfolio image" style="height:250px; width:100%;"/>
										<div class="isotope-overlay">
										
										</div><!-- /.isotope-overlay -->
									</div>
									<div class="item">
										<img src="assets/images/portfolio/p6.jpg" alt="portfolio image" style="height:250px; width:100%;"/>
										<div class="isotope-overlay">
										
										</div><!-- /.isotope-overlay -->
									</div>
									<!-- /.item -->
								</div><!-- /.col -->

								<div class="col-sm-4">
									<div class="item">
										<img src="assets/images/portfolio/p4.jpg" alt="portfolio image" style="height:250px; width:100%;"/>
										<div class="isotope-overlay">
										
										</div><!-- /.isotope-overlay -->
									</div><!-- /.item -->
									<div class="item">
										<img src="assets/images/portfolio/p5.jpg" alt="portfolio image" style="height:250px; width:100%;"/>
										<div class="isotope-overlay">
											
										</div><!-- /.isotope-overlay -->
									</div><!-- /.item -->
								</div><!-- /.col -->
							</div><!-- /.row -->
						</div><!--/.isotope-->
					</div><!--/.gallery-content-->
				</div><!--/.container-->
			</div><!--/.portfolio-details-->

		</section><!--/.portfolio-->
		<!--portfolio end -->


		<!--contact start -->
		<section id="contact" class="contact">
			<div class="section-heading text-center">
				<h2>contact me</h2>
			</div>
			<div class="container">
				<div class="contact-content">
					<div class="row">
						<div class="col-md-offset-1 col-md-5 col-sm-6">
							<div class="single-contact-box">
								<div class="contact-form">
									<form method="post" action="index.php">
										<div class="row">
											<div class="col-sm-6 col-xs-12">
												<div class="form-group">
												  <input type="text" class="form-control" id="name" placeholder="Nom*" name="Name" required />
												</div><!--/.form-group-->
											</div><!--/.col-->
											<div class="col-sm-6 col-xs-12">
												<div class="form-group">
													<input type="text" class="form-control" id="email" placeholder="Email*" name="Email" required />
												</div><!--/.form-group-->
											</div><!--/.col-->
										</div><!--/.row-->
										<div class="row">
											<div class="col-sm-12">
												<div class="form-group">
													<input type="text" class="form-control" id="Téléphone" placeholder="Téléphone" name="Phone" required />
												</div><!--/.form-group-->
											</div><!--/.col-->
										</div><!--/.row-->
										<div class="row">
											<div class="col-sm-12">
												<div class="form-group">
													<textarea class="form-control" cols="30" rows="7" id="comment" placeholder="Message" name="Message" required></textarea>
												</div><!--/.form-group-->
											</div><!--/.col-->
										</div><!--/.row-->
										
										<div class="row">
											<div class="col-sm-12">
												
												  <input name="submit" type="submit" id="submit" value="Envoyer Message" class="btn btn-primary py-3 px-5">
											<!--/.single-single-contact-btn-->
											</div><!--/.col-->
										</div><!--/.row-->
									
									
				
									</form><!--/form-->
							
	<?php
// Déclaration de la regex permettant de vérifier l'adresse email
$mailRegex = "#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#";
$phoneRegex = "#(\+[0-9]{2}\([0-9]\))?[0-9]{10}#";
	
	if(isset($_POST['submit'])){
	$nom=htmlspecialchars($_POST['Name']);
	$email=htmlspecialchars($_POST['Email']);
	$tel=htmlspecialchars($_POST['Phone']);
	$msg=htmlspecialchars($_POST['Message']);
	
	$to='hamadousouhila87@gmail.com';
	$sujet='contact';
	$message="Nom:".$nom."\n"."Telephone:".$tel."\n"."Message:"."\n\n".$msg;
	if (!preg_match($mailRegex, $email))
       echo "<div class='col-lg-offset-1 col-lg-10 alert alert-danger'><center>Indiquer une adresse email valide !</center></div>";
else if (!preg_match($phoneRegex, $tel))
   echo "<div class='col-lg-offset-1 col-lg-10 alert alert-danger'><center>Format téléphone invalide !</center></div>";
else{	$headers="From:".$email;
if(@mail($to,$sujet,$message,$headers))
 echo"<div class='col-lg-offset-1 col-lg-10 alert alert-success'><center>Vôtre message à été envoyé avec succès</center></div>";

else
 echo"<div class='col-lg-offset-1 col-lg-10 alert alert-danger'><center>Erreur, renvoyer vôtre message</center></div>";
}}
?>	 						
							
							
								</div><!--/.contact-form-->
							</div><!--/.single-contact-box-->
						</div><!--/.col-->
						<div class="col-md-offset-1 col-md-5 col-sm-6">
							<div class="single-contact-box">
								<div class="contact-adress">
									<div class="contact-add-head">
										<h3>hamadou souhila</h3>
										<p>BIOCHIMISTE & IMMUNOLOGUE</p>
									</div>
									<div class="contact-add-info">
										<div class="single-contact-add-info">
											<h3>phone</h3>
											<p>+213 541 461 871</p>
										</div>
										<div class="single-contact-add-info">
											<h3>email</h3>
											<p>hamadousouhila87@gmail.com</p>
										</div>
									
									</div>
								</div><!--/.contact-adress-->
								<div class="hm-foot-icon">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-twitter"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li><!--/li-->
										<li><a href="#"><i class="fa fa-instagram"></i></a></li><!--/li-->
									</ul><!--/ul-->
								</div><!--/.hm-foot-icon-->
							</div><!--/.single-contact-box-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.contact-content-->
			</div><!--/.container-->

		</section><!--/.contact-->
		<!--contact end -->

		<!--footer-copyright start-->
		<footer id="footer-copyright" class="footer-copyright">
			<div class="container">
				<div class="hm-footer-copyright text-center">
					<p>
						&copy; copyright Souhila Hamadou. developed by Golden Corp<a href="https://www.themesine.com/">.</a>
					</p><!--/p-->
				</div><!--/.text-center-->
			</div><!--/.container-->

			<div id="scroll-Top">
				<div class="return-to-top">
					<i class="fa fa-angle-up " id="scroll-top" ></i>
				</div>
				
			</div><!--/.scroll-Top-->
			
        </footer><!--/.footer-copyright-->
		<!--footer-copyright end-->
		
		<!-- Include all js compiled plugins (below), or include individual files as needed -->

		<script src="assets/js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		<!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>
		
		<!-- jquery.sticky.js -->
		<script src="assets/js/jquery.sticky.js"></script>
		
		<!-- for progress bar start-->

		<!-- progressbar js -->
		<script src="assets/js/progressbar.js"></script>

		<!-- appear js -->
		<script src="assets/js/jquery.appear.js"></script>

		<!-- for progress bar end -->

		<!--owl.carousel.js-->
        <script src="assets/js/owl.carousel.min.js"></script>


		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
		
        
        <!--Custom JS-->
        <script src="assets/js/custom.js"></script>
        
    </body>
	
</html>